#include <stdio.h>
#include <string.h>

int main(void)
{
    char buffer[10];

    strcpy(buffer, "This string is too long"); // BUFFER OVERFLOW
    printf("%s\n", buffer);

    return 0;
}
