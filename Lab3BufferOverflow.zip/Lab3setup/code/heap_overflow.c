#include <stdlib.h>
#include <string.h>

int main() {
    char *heapBuffer = malloc(10);  // allocate 10 bytes
    strcpy(heapBuffer, "This is too long!"); // overflows buffer
    free(heapBuffer);
    return 0;
}

