#include <stdio.h>

int main(void)
{
    char buffer[10];

    snprintf(buffer, sizeof(buffer), "%s", "This string is too long");
    printf("%s\n", buffer);

    return 0;
}
