#Save as: bank_account_race_fixed.py

class my_class(object):
    pass

import threading
import time


class BankAccount:
    """
    A bank account with synchronized deposit and withdraw
    using Lock + Condition (Java synchronized / wait / notifyAll).
    """

    def __init__(self):
        self.balance = 0
        self.lock = threading.Lock()
        self.condition = threading.Condition(self.lock)

    def deposit(self, amount):
        with self.condition:
            print(f"{threading.current_thread().name} Depositing {amount}", end="")

            new_balance = self.balance + amount
            print(f", new balance is {new_balance}")
            self.balance = new_balance

            # Java notifyAll()
            self.condition.notify_all()

    def withdraw(self, amount):
        with self.condition:
            while self.balance < amount:
                # Java wait()
                self.condition.wait()

            print(f"{threading.current_thread().name} Withdrawing {amount}", end="")

            new_balance = self.balance - amount
            print(f", new balance is {new_balance}")
            self.balance = new_balance

    def get_balance(self):
        with self.lock:
            return self.balance


class DepositThread(threading.Thread):
    REPETITIONS = 10
    DELAY = 0.01  # 10 ms

    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(self.REPETITIONS):
            self.account.deposit(self.amount)
            time.sleep(self.DELAY)


class WithdrawThread(threading.Thread):
    REPETITIONS = 10
    DELAY = 0.01  # 10 ms

    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(self.REPETITIONS):
            self.account.withdraw(self.amount)
            time.sleep(self.DELAY)


if __name__ == "__main__":
    account = BankAccount()

    t0 = DepositThread(account, 100)
    t1 = WithdrawThread(account, 100)
    t2 = DepositThread(account, 100)
    t3 = WithdrawThread(account, 100)

    t0.start()
    t1.start()
    t2.start()
    t3.start()

    t0.join()
    t1.join()
    t2.join()
    t3.join()

    print("\nFinal balance:", account.get_balance())



