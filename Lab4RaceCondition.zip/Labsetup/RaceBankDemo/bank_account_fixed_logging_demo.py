#bank_account_fixed_logging_demo.py

import threading
import time
from datetime import datetime


class BankAccount:
    """
    A bank account with synchronized deposit and withdraw,
    enhanced with logging to show thread interleaving.
    """

    def __init__(self):
        self.balance = 0
        self.lock = threading.Lock()
        self.condition = threading.Condition(self.lock)

    def deposit(self, amount):
        with self.condition:
            self.log(f"ENTER deposit({amount})")

            new_balance = self.balance + amount
            self.sleep_quietly(0.02)  # widen interleaving window
            self.balance = new_balance

            self.log(f"DEPOSITED {amount} | balance = {self.balance}")

            # Java notifyAll()
            self.condition.notify_all()
            self.log("NOTIFY waiting threads")

            self.log("EXIT deposit")

    def withdraw(self, amount):
        with self.condition:
            self.log(f"ENTER withdraw({amount})")

            while self.balance < amount:
                self.log(f"WAIT (balance = {self.balance})")
                self.condition.wait()
                self.log("RESUMED after wait")

            new_balance = self.balance - amount
            self.sleep_quietly(0.02)
            self.balance = new_balance

            self.log(f"WITHDREW {amount} | balance = {self.balance}")
            self.log("EXIT withdraw")

    def get_balance(self):
        with self.lock:
            return self.balance

    def sleep_quietly(self, seconds):
        time.sleep(seconds)

    def log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        print(f"{timestamp} | {threading.current_thread().name} | {message}")


class DepositThread(threading.Thread):
    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(5):
            self.account.deposit(self.amount)
            time.sleep(0.05)


class WithdrawThread(threading.Thread):
    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(5):
            self.account.withdraw(self.amount)
            time.sleep(0.05)


if __name__ == "__main__":
    account = BankAccount()

    DepositThread(account, 100).start()
    WithdrawThread(account, 100).start()
    DepositThread(account, 100).start()
    WithdrawThread(account, 100).start()

