import threading
import time


class BankAccount:
    """
    A bank account whose balance can be changed by
    deposits and withdrawals (INTENTIONALLY UNSAFE).
    """

    def __init__(self):
        self.balance = 0

    # NOT synchronized race condition here
    def deposit(self, amount):
        print(f"{threading.current_thread().name} depositing {amount}", end="")

        new_balance = self.balance + amount

        # Artificial delay to widen race window
        time.sleep(0.001)

        print(f", new balance is {new_balance}")
        self.balance = new_balance

    # NOT synchronized race condition here
    def withdraw(self, amount):
        print(f"{threading.current_thread().name} withdrawing {amount}", end="")

        new_balance = self.balance - amount

        # Artificial delay
        time.sleep(0.001)

        print(f", new balance is {new_balance}")
        self.balance = new_balance

    def get_balance(self):
        return self.balance


class DepositThread(threading.Thread):
    REPETITIONS = 10
    DELAY = 0.01

    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(self.REPETITIONS):
            self.account.deposit(self.amount)
            time.sleep(self.DELAY)


class WithdrawThread(threading.Thread):
    REPETITIONS = 10
    DELAY = 0.01

    def __init__(self, account, amount):
        super().__init__()
        self.account = account
        self.amount = amount

    def run(self):
        for _ in range(self.REPETITIONS):
            self.account.withdraw(self.amount)
            time.sleep(self.DELAY)


if __name__ == "__main__":
    account = BankAccount()

    t0 = DepositThread(account, 100)
    t1 = WithdrawThread(account, 100)

    t0.start()
    t1.start()

    t0.join()
    t1.join()

    print("\nFinal balance:", account.get_balance())

